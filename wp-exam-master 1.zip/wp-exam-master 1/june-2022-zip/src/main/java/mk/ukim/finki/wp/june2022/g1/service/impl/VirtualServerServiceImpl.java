package mk.ukim.finki.wp.june2022.g1.service.impl;

import mk.ukim.finki.wp.june2022.g1.model.OSType;
import mk.ukim.finki.wp.june2022.g1.model.User;
import mk.ukim.finki.wp.june2022.g1.model.VirtualServer;
import mk.ukim.finki.wp.june2022.g1.model.exceptions.InvalidUserIdException;
import mk.ukim.finki.wp.june2022.g1.model.exceptions.InvalidVirtualMachineIdException;
import mk.ukim.finki.wp.june2022.g1.repository.UserRepository;
import mk.ukim.finki.wp.june2022.g1.repository.VirtualServerRepository;
import mk.ukim.finki.wp.june2022.g1.service.VirtualServerService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class VirtualServerServiceImpl implements VirtualServerService {

    private final VirtualServerRepository virtualServerRepository;
    private final UserRepository userRepository;

    public VirtualServerServiceImpl(VirtualServerRepository virtualServerRepository, UserRepository userRepository) {
        this.virtualServerRepository = virtualServerRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<VirtualServer> listAll() {
        return this.virtualServerRepository.findAll();
    }

    @Override
    public VirtualServer findById(Long id) {
        return this.virtualServerRepository.findById(id).orElseThrow(InvalidVirtualMachineIdException::new);
    }

    @Override
    public VirtualServer create(String name, String ipAddress, OSType osType, List<Long> ownersIds, LocalDate launchDate) {
        List<User> owners = this.userRepository.findAllById(ownersIds);
        VirtualServer virtualServer = new VirtualServer(name, ipAddress, osType, owners, launchDate);

        return this.virtualServerRepository.save(virtualServer);
    }

    @Override
    public VirtualServer update(Long id, String name, String ipAddress, OSType osType, List<Long> ownersIds) {
        VirtualServer virtualServer = this.findById(id);

        virtualServer.setInstanceName(name);
        virtualServer.setIpAddress(ipAddress);
        virtualServer.setOSType(osType);

        List<User> owners = this.userRepository.findAllById(ownersIds);
        virtualServer.setOwners(owners);

        return this.virtualServerRepository.save(virtualServer);
    }

    @Override
    public VirtualServer delete(Long id) {
        VirtualServer virtualServer = this.findById(id);
        this.virtualServerRepository.delete(virtualServer);
        return virtualServer;
    }

    @Override
    public VirtualServer markTerminated(Long id) {
        VirtualServer virtualServer = this.findById(id);
        //ne e moj kod
        virtualServer.setTerminated(true);
        virtualServerRepository.save(virtualServer);
        return virtualServer;
    }

    @Override
    public List<VirtualServer> filter(Long ownerId, Integer activeMoreThanDays) {

        User user;
        LocalDate date;

        if(ownerId != null && activeMoreThanDays != null){
            user = userRepository.findById(ownerId).orElseThrow(InvalidUserIdException::new);
            date = LocalDate.now().minusDays(activeMoreThanDays);
            return virtualServerRepository.findAllByOwnersAndLaunchDateBefore(user,date);
        }
        else if(ownerId != null){
            user = userRepository.findById(ownerId).orElseThrow(InvalidUserIdException::new);
            return virtualServerRepository.findAllByOwners(user);
        }
        else if(activeMoreThanDays != null){
            date = LocalDate.now().minusDays(activeMoreThanDays);
            return virtualServerRepository.findAllByLaunchDateBefore(date);
        }
        return listAll();
    }



}
