package mk.ukim.finki.wp.jan2022.g2.model;

public enum DiscussionTag {
    IT,
    FINANCE,
    OTHER
}
