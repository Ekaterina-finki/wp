package mk.ukim.finki.wp.jan2022.g2.service.impl;

import mk.ukim.finki.wp.jan2022.g2.model.Discussion;
import mk.ukim.finki.wp.jan2022.g2.model.DiscussionTag;
import mk.ukim.finki.wp.jan2022.g2.model.User;
import mk.ukim.finki.wp.jan2022.g2.model.exceptions.InvalidDiscussionIdException;
import mk.ukim.finki.wp.jan2022.g2.model.exceptions.InvalidUserIdException;
import mk.ukim.finki.wp.jan2022.g2.repository.DiscussionRepository;
import mk.ukim.finki.wp.jan2022.g2.repository.UserRepository;
import mk.ukim.finki.wp.jan2022.g2.service.DiscussionService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DiscussionServiceImpl implements DiscussionService {

    private final DiscussionRepository discussionRepository;
    private final UserRepository userRepository;

    public DiscussionServiceImpl(DiscussionRepository discussionRepository, UserRepository userRepository) {
        this.discussionRepository = discussionRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<Discussion> listAll() {
        return this.discussionRepository.findAll();
    }

    @Override
    public Discussion findById(Long id) {
        return this.discussionRepository.findById(id).orElseThrow(InvalidDiscussionIdException::new);
    }

    @Override
    public Discussion create(String title, String description, DiscussionTag discussionTag,
                             List<Long> participantsIds, LocalDate dueDate) {

        List<User> participants = this.userRepository.findAllById(participantsIds);
        Discussion discussion = new Discussion(title, description, discussionTag, participants, dueDate);

        return this.discussionRepository.save(discussion);
    }

    @Override
    public Discussion update(Long id, String title, String description, DiscussionTag discussionTag,
                             List<Long> participantsIds) {
        Discussion discussion = this.findById(id);

        discussion.setTitle(title);
        discussion.setDescription(description);
        discussion.setTag(discussionTag);

        List<User> participants = this.userRepository.findAllById(participantsIds);
        discussion.setParticipants(participants);

        return this.discussionRepository.save(discussion);
    }

    @Override
    public Discussion delete(Long id) {
        Discussion discussion = this.findById(id);
        this.discussionRepository.delete(discussion);
        return discussion;
    }

    @Override
    public Discussion markPopular(Long id) {
        Discussion discussion = this.findById(id);

        discussion.setPopular(true);
        discussionRepository.save(discussion);
        return discussion;
    }

    @Override
    public List<Discussion> filter(Long participantId, Integer daysUntilClosing) {

        User user;
        LocalDate date;

        if(participantId != null && daysUntilClosing != null){
            user = userRepository.findById(participantId).orElseThrow(InvalidUserIdException::new);
            date = LocalDate.now().plusDays(daysUntilClosing);
            return discussionRepository.findAllByParticipantsAndDueDateIsBefore(user,date);
        }
        else if(participantId != null){
            user = userRepository.findById(participantId).orElseThrow(InvalidUserIdException::new);
            return discussionRepository.findAllByParticipants(user);
        }
        else if(daysUntilClosing != null){
            date = LocalDate.now().plusDays(daysUntilClosing);
            return discussionRepository.findAllByDueDateIsBefore(date);
        }
        return listAll();
    }
}
