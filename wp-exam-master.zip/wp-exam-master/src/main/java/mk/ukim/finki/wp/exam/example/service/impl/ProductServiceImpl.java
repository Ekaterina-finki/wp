package mk.ukim.finki.wp.exam.example.service.impl;

import mk.ukim.finki.wp.exam.example.model.Category;
import mk.ukim.finki.wp.exam.example.model.Product;
import mk.ukim.finki.wp.exam.example.model.exceptions.InvalidProductIdException;
import mk.ukim.finki.wp.exam.example.repository.CategoryRepository;
import mk.ukim.finki.wp.exam.example.repository.ProductRepository;
import mk.ukim.finki.wp.exam.example.repository.UserRepository;
import mk.ukim.finki.wp.exam.example.service.ProductService;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;

    public ProductServiceImpl(ProductRepository productRepository, CategoryRepository categoryRepository, UserRepository userRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<Product> listAllProducts() {
        return this.productRepository.findAll();
    }

    @Override
    public Product findById(Long id) {
        return this.productRepository.findById(id).orElseThrow(InvalidProductIdException::new);
    }

    @Override
    public Product create(String name, Double price, Integer quantity, List<Long> categoryIds) {
        List<Category> categories = this.categoryRepository.findAllById(categoryIds); //vo category impl ima exception od findbyid
        Product product = new Product(name, price, quantity, categories);

        return this.productRepository.save(product);
    }

    @Override
    public Product update(Long id, String name, Double price, Integer quantity, List<Long> categoryIds) {
        Product product = this.findById(id); //gore go napravivme, ima exception

        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);

        List<Category> categories = this.categoryRepository.findAllById(categoryIds);
        product.setCategories(categories);

        return this.productRepository.save(product);
    }

    @Override
    public Product delete(Long id) {
        Product product = this.findById(id); //gore go napravivme, ima exception
        this.productRepository.delete(product);
        return product;
    }

    @Override
    public List<Product> listProductsByNameAndCategory(String name, Long categoryId) { //za kraj
//        return new ArrayList<>();
        Category category = categoryId != null ? this.categoryRepository.findById(categoryId).orElse((Category) null) : null;
        if(name!=null && category!=null){
            return this.productRepository.findAllByNameLikeAndCategoriesContaining("%"+name+"%", category);
        }
        else if(name!=null){
            return this.productRepository.findAllByNameLike("%"+name+"%");
        }
        else if(category!=null){
            return this.productRepository.findAllByCategoriesContaining(category);
        }else{
            return this.productRepository.findAll();
        }


//        @Override
//        public VirtualServer markTerminated(Long id) {
//            VirtualServer virtualServer = this.findById(id);
//            virtualServer.setTerminated(true);
//            virtualServerRepository.save(virtualServer);
//            return virtualServer;
//        }
    }

//    pотребно е да овозможите пребарување на виртуелни машини според owner и денови активност
//            (launchDate <= (now - filtering days))
//    @Override
//    public List<VirtualServer> filter(Long ownerId, Integer activeMoreThanDays) {
//
//        User user;
//        LocalDate date;
//
//        if(ownerId != null && activeMoreThanDays != null){
//            user = userRepository.findById(ownerId).orElseThrow(InvalidUserIdException::new);
//            date = LocalDate.now().minusDays(activeMoreThanDays);
//            return virtualServerRepository.findAllByOwnersAndLaunchDateBefore(user,date);
//        }
//        else if(ownerId != null){
//            user = userRepository.findById(ownerId).orElseThrow(InvalidUserIdException::new);
//            return virtualServerRepository.findAllByOwners(user);
//        }
//        else if(activeMoreThanDays != null){
//            date = LocalDate.now().minusDays(activeMoreThanDays);
//            return virtualServerRepository.findAllByLaunchDateBefore(date);
//        }
//        return listAll();
//    }


//
//    Потребно е да овозможите пребарување на задачи според assignee и преостанати денови
//            (dueDate < now + filtering days)
//    @Override
//    public List<Task> filter(Long assigneeId, Integer lessThanDayBeforeDueDate) {
//
//        User assignee;
//        LocalDate date;
//
//        if(assigneeId != null && lessThanDayBeforeDueDate != null){
//            assignee = userRepository.findById(assigneeId).orElseThrow(InvalidUserIdException::new);
//            date = LocalDate.now().plusDays(lessThanDayBeforeDueDate);
//            return taskRepository.findAllByAssigneesAndDueDateBefore(assignee,date);
//        }
//        else if(assigneeId != null){
//            assignee = userRepository.findById(assigneeId).orElseThrow(InvalidUserIdException::new);
//            return taskRepository.findAllByAssignees(assignee);
//        }
//        else if(lessThanDayBeforeDueDate != null){
//            date = LocalDate.now().plusDays(lessThanDayBeforeDueDate);
//            return taskRepository.findAllByDueDateBefore(date);
//        }
//        return listAll();
//    }



//    Потребно е да овозможите пребарување на дискусии според participant и преостанати денови
//- (да ги врати сите дискусии кои ќе се затворат пред да помине тој број на денови)

//    @Override
//    public List<Discussion> filter(Long participantId, Integer daysUntilClosing) {
//
//        User user;
//        LocalDate date;
//
//        if(participantId != null && daysUntilClosing != null){
//            user = userRepository.findById(participantId).orElseThrow(InvalidUserIdException::new);
//            date = LocalDate.now().plusDays(daysUntilClosing);
//            return discussionRepository.findAllByParticipantsAndDueDateIsBefore(user,date);
//        }
//        else if(participantId != null){
//            user = userRepository.findById(participantId).orElseThrow(InvalidUserIdException::new);
//            return discussionRepository.findAllByParticipants(user);
//        }
//        else if(daysUntilClosing != null){
//            date = LocalDate.now().plusDays(daysUntilClosing);
//            return discussionRepository.findAllByDueDateIsBefore(date);
//        }
//        return listAll();
//    }
}
